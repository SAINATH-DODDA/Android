package com.example.doddasainath.project2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.android.miwok.R;

public class NumbersClickListener implements  View.OnClickListener{


     public void onClick(View view)
    {
        Toast.makeText(view.getContext(),"Open the list of numbers",Toast.LENGTH_SHORT).show();

    }


}
