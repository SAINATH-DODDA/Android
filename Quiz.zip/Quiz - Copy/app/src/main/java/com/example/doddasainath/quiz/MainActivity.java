package com.example.doddasainath.quiz;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;

import static android.R.id.message;

public class MainActivity extends AppCompatActivity {
    public int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void onRadioButtonClicked(View view) {
    }


    public void sainath(View view) {

        RadioButton whippedCreamCheckBox = (RadioButton) findViewById(R.id.radio_ninjas);
        boolean hasWhippedCream = whippedCreamCheckBox.isChecked();

        if (hasWhippedCream) {
            count = count + 1;

           Log.v("Pirates", String.valueOf(count));   // Do something in response to button click
        }

        Intent intent = new Intent(this, question2.class);
        intent.putExtra("intVariableName", count);
        startActivity(intent);
    }

}






