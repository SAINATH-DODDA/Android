package com.example.doddasainath.quiz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

public class question3 extends AppCompatActivity {
         String text; int count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question3);
        Intent mIntent = getIntent();
        count = mIntent.getIntExtra("intVariableName", 0);

    }

    public void submit3(View view) {

        EditText edit_text = (EditText) findViewById(R.id.editText);
        text= edit_text.getEditableText().toString();

        if(text.equals("Nougat")) {
            count = count + 1;

            Log.v(text, String.valueOf(count));   // Do something in response to button click

        }

        Intent intent = new Intent(this, question4.class);
        intent.putExtra("intVariableName", count);
        startActivity(intent);


    }

}
