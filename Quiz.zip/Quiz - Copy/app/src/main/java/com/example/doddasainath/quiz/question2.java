package com.example.doddasainath.quiz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;

import static android.R.id.message;

public class question2 extends AppCompatActivity {
       int count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question2);


         Intent mIntent = getIntent();
         count = mIntent.getIntExtra("intVariableName", 0);
    }






    public void SUBMIT(View view) {

        CheckBox whippedCreamCheckBox = (CheckBox) findViewById(R.id.checkbox_seven);
        boolean hasWhippedCream = whippedCreamCheckBox.isChecked();

        CheckBox whippedCreamCheckBox1 = (CheckBox) findViewById(R.id.checkbox_six);
        boolean hasWhippedCream1 = whippedCreamCheckBox1.isChecked();



        if (hasWhippedCream&hasWhippedCream1) {
             count = count + 1;

            Log.v("Pirates",String.valueOf(count));   // Do something in response to button click
        }


        Intent intent = new Intent(this, question3.class);
        intent.putExtra("intVariableName", count);
        startActivity(intent);

    }

}
