package com.example.doddasainath.quiz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class grade extends AppCompatActivity {

    int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade);
        Intent mIntent = getIntent();
        count = mIntent.getIntExtra("intVariableName", 0);

        TextView textView = (TextView) findViewById(R.id.grade_text);
        textView.setText("You have scored "+count*25+"/100"+" points ");

    }

}