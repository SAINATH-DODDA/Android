package com.example.doddasainath.quiz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;

public class question4 extends AppCompatActivity {


    int count;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question4);
        Intent mIntent = getIntent();
        count = mIntent.getIntExtra("intVariableName", 0);

    }

    public void submit4(View view) {

        RadioButton whippedCreamCheckBox = (RadioButton) findViewById(R.id.text_true);
        boolean hasWhippedCream = whippedCreamCheckBox.isChecked();



        if (hasWhippedCream) {
            count = count + 1;

            Log.v("Pirates",String.valueOf(count));   // Do something in response to button click
        }


        Intent intent = new Intent(this, grade.class);
        intent.putExtra("intVariableName", count);
         startActivity(intent);

    }


}
